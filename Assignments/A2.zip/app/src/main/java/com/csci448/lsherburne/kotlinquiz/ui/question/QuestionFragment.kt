package com.csci448.lsherburne.kotlinquiz.ui.question

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.csci448.lsherburne.kotlinquiz.R
import com.csci448.lsherburne.kotlinquiz.data.QuizViewModel
import com.csci448.lsherburne.kotlinquiz.data.QuizViewModelFactory
import com.csci448.lsherburne.kotlinquiz.data.questionType
import com.csci448.lsherburne.kotlinquiz.databinding.FragmentQuestionBinding


class QuestionFragment : Fragment() {
    private lateinit var quizViewModel : QuizViewModel
    private var _binding: FragmentQuestionBinding? = null
    private val binding get() = _binding!!
    private lateinit var _answeredQuestions : Array<Int?>

    companion object {
        private const val LOG_TAG = "448.QuestionFragment"

        // Add key strings for use with the bundle
        const val KEY_INDEX = "index"
        const val KEY_SCORE = "score"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        Log.d(LOG_TAG, "OnCreateView() called")

        // factory starts with first question and score is 0
        val factory = QuizViewModelFactory(0, 0)
        quizViewModel = ViewModelProvider(requireActivity(), factory).get(factory.getViewModelClass())
        _answeredQuestions = arrayOfNulls(quizViewModel.numQuestions)

        _binding = FragmentQuestionBinding.inflate(inflater, container, false)
        val view = binding.root

        return view

    }

    override fun onSaveInstanceState(savedInstanceState: Bundle) {
        super.onSaveInstanceState(savedInstanceState)
        Log.d(QuestionFragment.LOG_TAG, "OnSaveInstanceState() called")
        savedInstanceState.putInt(KEY_INDEX, quizViewModel.currentIndex)
        savedInstanceState.putInt(KEY_SCORE, quizViewModel.currentScore)

    }

    private fun updateQuestion() {
        // set the text of the score textview
        setCurrentScoreText()

        // set the text of the question textview
        binding.questionTextView.text = resources.getString(quizViewModel.currentQuestionTextId)

        // set the buttons/blank to fill in based on the questionType
        if (quizViewModel.currentType == questionType.TRUEFALSE) {
            // true/false buttons formatted and visible
            binding.thirdButton?.visibility = View.VISIBLE
            binding.thirdButton?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22F)
            binding.thirdButton?.text = resources.getString(R.string.true_label)
            binding.fourthButton?.visibility = View.VISIBLE
            binding.fourthButton?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22F)
            binding.fourthButton?.text = resources.getString(R.string.false_label)

            // set other elements to invisible
            binding.firstButton?.visibility = View.INVISIBLE
            binding.secondButton?.visibility = View.INVISIBLE

            // format layout
            binding.upperLayout?.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            binding.lowerLayout?.layoutParams =
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 0)

            // disable buttons if necessary
            if (_answeredQuestions.contains(quizViewModel.currentIndex % quizViewModel.numQuestions)) {
                binding.thirdButton?.isEnabled = false
                binding.fourthButton?.isEnabled = false

                // color the disabled buttons to indicate that the question was already answered
                if (quizViewModel.currentQuestionAnswer == "True") {
                    binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.mint, null))
                    binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
                } else {
                    binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
                    binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.mint, null))
                }
            } else {
                binding.thirdButton?.isEnabled = true
                binding.fourthButton?.isEnabled = true
                binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.purple_200, null))
                binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.purple_200, null))
            }

        } else if (quizViewModel.currentType == questionType.MULTIPLECHOICE) {
            // bottom two buttons formatted and visible
            binding.thirdButton?.visibility = View.VISIBLE
            binding.thirdButton?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            binding.thirdButton?.text = resources.getString(R.string.third_choice_button_label)
            binding.fourthButton?.visibility = View.VISIBLE
            binding.fourthButton?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            binding.fourthButton?.text = resources.getString(R.string.fourth_choice_button_label)

            // top two buttons formatted and visible
            binding.firstButton?.visibility = View.VISIBLE
            binding.secondButton?.visibility = View.VISIBLE

            // format layout
            binding.upperLayout?.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            binding.lowerLayout?.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 0)

            // disable buttons if necessary
            if (_answeredQuestions.contains(quizViewModel.currentIndex % quizViewModel.numQuestions)) {
                binding.firstButton?.isEnabled = false
                binding.secondButton?.isEnabled = false
                binding.thirdButton?.isEnabled = false
                binding.fourthButton?.isEnabled = false

                // color the disabled buttons to indicate that the question was already answered
                binding.firstButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.mint, null))
                binding.secondButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
                binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
                binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
            } else {
                binding.firstButton?.isEnabled = true
                binding.secondButton?.isEnabled = true
                binding.thirdButton?.isEnabled = true
                binding.fourthButton?.isEnabled = true

                binding.firstButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.purple_200, null))
                binding.secondButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.purple_200, null))
                binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.purple_200, null))
                binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.purple_200, null))
            }
        } else if (quizViewModel.currentType == questionType.FILLINTHEBLANK) {
            // set all four buttons to invisible
            binding.firstButton?.visibility = View.INVISIBLE
            binding.secondButton?.visibility = View.INVISIBLE
            binding.thirdButton?.visibility = View.INVISIBLE
            binding.fourthButton?.visibility = View.INVISIBLE

            // format layout
            binding.upperLayout?.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 0)
            binding.lowerLayout?.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            if (_answeredQuestions.contains(quizViewModel.currentIndex % quizViewModel.numQuestions)) {
                binding.submitButton?.isEnabled = false
                binding.submitButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
            } else {
                binding.submitButton?.isEnabled = true
                binding.submitButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.purple_200, null))
            }
        }
    }

    private fun setCurrentScoreText() {
        binding.scoreTextView.text = quizViewModel.currentScore.toString()
    }

    private fun checkAnswer(answer: String) {
        // save question in list of answered questions
        _answeredQuestions[quizViewModel.currentIndex] = quizViewModel.currentIndex

        // disable buttons
        binding.firstButton?.isEnabled = false
        binding.secondButton?.isEnabled = false
        binding.thirdButton?.isEnabled = false
        binding.fourthButton?.isEnabled = false
        binding.submitButton?.isEnabled = false

        // color the disabled buttons to indicate that the question was already answered
        if (quizViewModel.currentType == questionType.TRUEFALSE) {
            if (quizViewModel.currentQuestionAnswer == "True") {
                binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.mint, null))
                binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
            } else {
                binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
                binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.mint, null))
            }
        } else if (quizViewModel.currentType == questionType.MULTIPLECHOICE) {
            binding.firstButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.mint, null))
            binding.secondButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
            binding.thirdButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
            binding.fourthButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
        } else {
            binding.submitButton?.setBackgroundColor(ResourcesCompat.getColor(resources, R.color.gray, null))
        }


        // pass value through quiz master method: isAnswerCorrect()
        val isCorrect = quizViewModel.isAnswerCorrect(answer)
        Log.d(LOG_TAG, "$isCorrect")

        if (quizViewModel.didUserCheat) {   // cheater toast
            if (isCorrect) {    // correct toast
                Toast.makeText(requireContext(), R.string.cheat_toast, Toast.LENGTH_SHORT).show()
            } else {    // incorrect toast
                Toast.makeText(requireContext(), R.string.incorrect_toast, Toast.LENGTH_SHORT).show()
            }
        } else {
            if (isCorrect) {    // correct toast
                Toast.makeText(requireContext(), R.string.correct_toast, Toast.LENGTH_SHORT).show()
                setCurrentScoreText()
            } else {    // incorrect toast
                Toast.makeText(requireContext(), R.string.incorrect_toast, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun moveToQuestion(direction: Int) {
        if (direction > 0) {
            // if positive move to next question
            quizViewModel.moveToNext()
        } else if (direction < 0) {
            // if negative move to previous question
            quizViewModel.moveToPrevious()
        }

        updateQuestion()
    }


    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.d(LOG_TAG, "OnAttach() called")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(LOG_TAG, "OnCreate() called")

        val currentIndex = savedInstanceState?.getInt(KEY_INDEX, 0) ?: 0
        val currentScore = savedInstanceState?.getInt(KEY_SCORE, 0) ?: 0
        val factory = QuizViewModelFactory(currentIndex, currentScore)
        quizViewModel = ViewModelProvider(this@QuestionFragment, factory).get(QuizViewModel::class.java)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(LOG_TAG, "OnViewCreated() called")

        updateQuestion()

        // multiple choice button click listeners
        binding.firstButton?.setOnClickListener {checkAnswer("Guillotine")}
        binding.secondButton?.setOnClickListener {checkAnswer("Electric Chair")}

        // true/false and multiple choice button click listeners
        binding.thirdButton.setOnClickListener {
            if (quizViewModel.currentType == questionType.TRUEFALSE) {
                checkAnswer("True")
            } else if (quizViewModel.currentType == questionType.MULTIPLECHOICE) {
                checkAnswer("Walking The Plank")
            }
        }
        binding.fourthButton.setOnClickListener {
            if (quizViewModel.currentType == questionType.TRUEFALSE) {
                checkAnswer("False")
            } else if (quizViewModel.currentType == questionType.MULTIPLECHOICE) {
                checkAnswer("Lethal Injection")
            }
        }

        // submit button click listener
        binding.submitButton?.setOnClickListener {
            checkAnswer(binding.fillInAnswer?.getText().toString())
        }

        // cheat button click listener
        binding.cheatButton.setOnClickListener{
            //view.findNavController().navigate(R.id.action_questionFragment_to_cheatFragment)
            Log.d(LOG_TAG, "Cheat button...")
            val action = QuestionFragmentDirections.actionQuestionFragmentToCheatFragment(quizViewModel.currentQuestionAnswer.toString())
            view.findNavController().navigate(action)
        }

        // previous/next button click listeners
        binding.previousButton.setOnClickListener {moveToQuestion(-1)}
        binding.nextButton.setOnClickListener {moveToQuestion(1)}
    }

    override fun onStart() {
        super.onStart()
        Log.d(LOG_TAG, "OnStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "OnResume() called")
    }

    override fun onPause() {
        Log.d(LOG_TAG, "OnPause() called")
        super.onPause()
    }

    override fun onStop() {
        Log.d(LOG_TAG, "OnStop() called")
        super.onStop()
    }

    override fun onDestroyView() {
        Log.d(LOG_TAG, "OnDestroyView() called")
        super.onDestroyView()
        _binding = null
    }

    override fun onDestroy() {
        Log.d(LOG_TAG, "OnDestroy() called")
        super.onDestroy()
    }

    override fun onDetach() {
        Log.d(LOG_TAG, "OnDetach() called")
        super.onDetach()
    }
}

