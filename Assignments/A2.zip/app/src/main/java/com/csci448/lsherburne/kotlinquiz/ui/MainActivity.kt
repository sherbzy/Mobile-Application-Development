package com.csci448.lsherburne.kotlinquiz.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.ViewModelProvider
import com.csci448.lsherburne.kotlinquiz.R
import com.csci448.lsherburne.kotlinquiz.data.QuizViewModel
import com.csci448.lsherburne.kotlinquiz.data.QuizViewModelFactory

class MainActivity : AppCompatActivity() {
    private lateinit var quizViewModel: QuizViewModel

    companion object {
        private const val LOG_TAG = "448.MainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(LOG_TAG, "OnCreate() called")
    }

    override fun onStart() {
        super.onStart()
        Log.d(LOG_TAG, "OnStart() called")

    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "OnResume() called")
    }

    override fun onPause() {
        Log.d(LOG_TAG, "OnPause() called")
        super.onPause()
    }

    override fun onStop() {
        Log.d(LOG_TAG, "OnStop() called")
        super.onStop()
    }

    override fun onDestroy() {
        Log.d(LOG_TAG, "OnDestroy() called")
        super.onDestroy()
    }

}