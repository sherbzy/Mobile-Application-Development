package com.csci448.lsherburne.kotlinquiz.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider


// QuizViewModelFactory.kt
class QuizViewModelFactory(private val currentIndex: Int, private val currentScore: Int) : ViewModelProvider.Factory {

    fun getViewModelClass() = QuizViewModel::class.java

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return modelClass.getConstructor(Int::class.java, Int::class.java).newInstance(currentIndex, currentScore)
//        if( modelClass.isAssignableFrom(getViewModelClass()) )
//            return modelClass.getConstructor(Int::class.java, Int::class.java).newInstance(currentIndex, currentScore)
//        throw IllegalArgumentException(“Unknown ViewModel”)
    }
}
