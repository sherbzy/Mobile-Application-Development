package com.csci448.lsherburne.kotlinquiz.data

import android.util.Log
import androidx.lifecycle.ViewModel
import com.csci448.lsherburne.kotlinquiz.R


// handles the business logic of playing the quiz
class QuizViewModel (private var currentQuestionIndex : Int, private var currentPlayerScore : Int): ViewModel() {
    // private val theQuestion = Question(R.string.question_1, false)
    private val questionBank: MutableList<Question> = mutableListOf()
    // private var currentQuestionIndex = 0
    // private var score = 0
    private var cheated = false
    private var isDone = false

    companion object {
        private const val LOG_TAG = "448.QuizViewModel"
    }

    init {
        Log.d(LOG_TAG, "ViewModel instance created")

        questionBank.add(Question(R.string.question_1, "False", questionType.TRUEFALSE))
        questionBank.add(Question(R.string.question_2, "False", questionType.TRUEFALSE))
        questionBank.add(Question(R.string.question_3, "False", questionType.TRUEFALSE))
        questionBank.add(Question(R.string.question_4, "True", questionType.TRUEFALSE))

        // multiple choice question
        questionBank.add(Question(R.string.multiple_choice_question, "Guillotine", questionType.MULTIPLECHOICE))

        // fill in the blank question
        questionBank.add(Question(R.string.fill_in_the_blank_question, "Hello, Beastie", questionType.FILLINTHEBLANK))
    }

    private val currentQuestion : Question
        get() = questionBank[currentQuestionIndex]

    val currentQuestionTextId : Int
        get() = currentQuestion.textResId

    val currentQuestionAnswer: String
        get() = currentQuestion.answer

    val currentScore: Int
        get() = currentPlayerScore

    val currentIndex : Int
        get() = currentQuestionIndex

    val currentType : questionType
        get() = currentQuestion.questionType

    val didUserCheat : Boolean
        get() = cheated

    val isQuestionDone : Boolean
        get() = isDone

    val numQuestions : Int
        get() = questionBank.size

    public fun userCheated() {
        cheated = true
    }

    public fun isAnswerCorrect(answer: String): Boolean {
        // check the type of question first
        if (currentType == questionType.FILLINTHEBLANK) {
            // check the answer, but ignore the case for fill in the blank questions
            if (answer.equals(currentQuestionAnswer, true)) {
                if (!cheated) { // check for cheating
                    currentPlayerScore++
                }
                return true
            }
            return false
        } else {
            // otherwise check the current answer and increment the score as usual
            if (answer == currentQuestionAnswer) {
                if (!cheated) { // check for cheating
                    currentPlayerScore++
                }
                return true
            }

            // return false if incorrect answer
            return false
        }
    }


    fun moveToNext() {
        currentQuestionIndex = (currentQuestionIndex + 1) % questionBank.size
        cheated = false
    }
    fun moveToPrevious() {
        currentQuestionIndex = (currentQuestionIndex - 1 + questionBank.size) % questionBank.size
        cheated = false
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(LOG_TAG, "ViewModel instance about to be destroyed")
    }
}