package com.csci448.lsherburne.kotlinquiz.data

import androidx.annotation.StringRes
import java.lang.reflect.Array

enum class questionType {
    TRUEFALSE, MULTIPLECHOICE, FILLINTHEBLANK
}

// represents a single question in the quiz
data class Question(@StringRes val textResId: Int, val answer: String, val questionType: questionType) {

}