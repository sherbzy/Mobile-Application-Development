package com.csci448.lsherburne.kotlinquiz.ui.cheat

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.csci448.lsherburne.kotlinquiz.R
import com.csci448.lsherburne.kotlinquiz.data.QuizViewModel
import com.csci448.lsherburne.kotlinquiz.data.QuizViewModelFactory
import com.csci448.lsherburne.kotlinquiz.databinding.FragmentCheatBinding
import com.csci448.lsherburne.kotlinquiz.databinding.FragmentQuestionBinding
import com.csci448.lsherburne.kotlinquiz.ui.question.QuestionFragment


class CheatFragment : Fragment() {
    private lateinit var quizViewModel : QuizViewModel
    private var _binding: FragmentCheatBinding? = null
    private val binding get() = _binding!!
    companion object {
        private const val LOG_TAG = "448.CheatFragment"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        Log.d(LOG_TAG, "onCreateView() called")
//        return inflater.inflate(R.layout.fragment_cheat, container, false)
        val factory = QuizViewModelFactory(0, 0)
        quizViewModel = ViewModelProvider(requireActivity(), factory).get(factory.getViewModelClass())

        _binding = FragmentCheatBinding.inflate(inflater, container, false)
        val view = binding.root

        val message = CheatFragmentArgs.fromBundle(requireArguments()).answer
        binding.answerTextView.text = message

        // show answer button click listener
        binding.showTheAnswerButton.setOnClickListener {
            binding.answerTextView.visibility = View.VISIBLE
            quizViewModel.userCheated()
        }

        return view
    }

//    override fun onSaveInstanceState(outState: Bundle) {
//        super.onSaveInstanceState(outState)
//        Log.d(LOG_TAG, "onSaveInstanceState() called")
//    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.d(LOG_TAG, "onAttach() called")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(LOG_TAG, "onCreate() called")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(LOG_TAG, "onViewCreated() called")
    }

    override fun onStart() {
        super.onStart()
        Log.d(LOG_TAG, "onStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "onResume() called")
    }

    override fun onPause() {
        Log.d(LOG_TAG, "onPause() called")
        super.onPause()
    }

    override fun onStop() {
        Log.d(LOG_TAG, "onStop() called")
        super.onStop()
    }

    override fun onDestroyView() {
        Log.d(LOG_TAG, "onDestroyView() called")
        super.onDestroyView()
    }

    override fun onDestroy() {
        Log.d(LOG_TAG, "onDestroy() called")
        super.onDestroy()
    }

    override fun onDetach() {
        Log.d(LOG_TAG, "onDetach() called")
        super.onDetach()
    }
}