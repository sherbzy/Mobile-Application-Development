Name: Lauren Sherburne
1. How did you structure your classes to allow for multiple question types in your question array?
	I used the same structure of classes, but added an enumerated type stored in each question which
	indicated the type of question being used.
2. How did your choice for Question #1 affect how you set up your ViewModel, View, and Controller?
	Using an enumerated type allowed simple addition of questions to the bank in the ViewModel
	however, the controller needed more lines of code to take care of the different types of 
	questions.
3. What difficulties did you have with the Controller passing information from the Model to the View?
	The biggest difficulty with passing the controller passing information from the model to the
	view was that information can be lost when the back button is pressed. I, therefore, saved
	necessary information in the bundle in order to maintain up-to-date information.
4. What was the role of the ViewModel?
	The ViewModel's role was to hold important information about the quiz's questions and answers.
	It was used for things such as checking if a given answer is correct or checking if the user
	cheated on one or more questions.